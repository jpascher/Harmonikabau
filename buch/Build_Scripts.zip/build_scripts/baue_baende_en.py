#!/usr/bin/env python3
"""
Erzeugt die zwei englischen Bände parallel zur deutschen Aufteilung:

Volume I  — Construction, Components, Builders   (46 chapters, 7 parts)
Volume II — Accordion Types and Related Instruments (45 chapters, 6 parts)
"""
import sys, os, shutil, subprocess, json, re
sys.path.insert(0, '/home/claude')
import verarbeite_quellen_en as vq

# ──────────────────────────────────────────────────────────
# DE → EN Anzeigetitel-Mapping für Kapitel-Überschriften
# (Wikipedia-Artikeltitel → englische Übersetzung im TOC)
# ──────────────────────────────────────────────────────────
TITEL_EN = {
    # ─ Komponenten und Mechanik ─
    "Akkordeon":                              "Accordion",
    "Handzuginstrument":                      "Hand-pulled instrument",
    "Harmonikainstrument":                    "Harmonica instrument",
    "Zunge (Tonerzeuger)":                    "Reed (tone generator)",
    "Durchschlagende Zunge":                  "Free reed",
    "Kanzelle":                               "Cell (Kanzelle)",
    "Cassotto":                               "Cassotto",
    "Register (Akkordeon)":                   "Registers (accordion)",
    "Tremolo (Akkordeon)":                    "Tremolo (accordion)",
    "Stradella-Bass":                         "Stradella bass",
    "Konverterbass":                          "Converter bass",
    "Melodiebass":                            "Melody bass",
    "Helikonstimmplatten":                    "Helicon reed plates",
    "Gleichton":                              "Unison-tone",
    "Wechseltönig":                           "Alternate-toned",
    "Wechselbass":                            "Alternating bass",
    "Bassakkordeon":                          "Bass accordion",
    # ─ Theorie ─
    "Stimmung (Musik)":                       "Tuning (music)",
    "Diatonik":                               "Diatonic",
    "Vallotti-Stimmung":                      "Vallotti tuning",
    "Handzuginstrumentenmacher":              "Hand-pulled instrument maker",
    "Akkordeonschule":                        "Accordion school",
    # ─ Erfinder, Pioniere, Erbauer (Eigennamen meist beibehalten) ─
    "Christian Gottlieb Kratzenstein":        "Christian Gottlieb Kratzenstein",
    "Bernhard Eschenbach":                    "Bernhard Eschenbach",
    "Johann Caspar Schlimbach":               "Johann Caspar Schlimbach",
    "Carl Friedrich Voit":                    "Carl Friedrich Voit",
    "Friedrich Sturm (Instrumentenbauer)":    "Friedrich Sturm (instrument maker)",
    "Anton Haeckl":                           "Anton Haeckl",
    "Anton Reinlein":                         "Anton Reinlein",
    "Christian Friedrich Ludwig Buschmann":   "Christian Friedrich Ludwig Buschmann",
    "Cyrill Demian":                          "Cyrill Demian",
    "Charles Wheatstone":                     "Charles Wheatstone",
    "William M. Goodrich":                    "William M. Goodrich",
    "Adolf Müller senior":                    "Adolf Müller senior",
    "Johann Wilhelm Rudolph Glier":           "Johann Wilhelm Rudolph Glier",
    "Paolo Soprani":                          "Paolo Soprani",
    "Josef Hlaváček":                         "Josef Hlaváček",
    "Lubas & Sohn":                           "Lubas & Son",
    "Josef Fleiß":                            "Josef Fleiß",
    "Anton Mervar":                           "Anton Mervar",
    "Peter Stachl":                           "Peter Stachl",
    "Novak Harmonikas":                       "Novak Harmonikas",
    "Otto Ludwig (Harmonikabauer)":           "Otto Ludwig (harmonica builder)",
    "Roman Gombotz":                          "Roman Gombotz",
    "Othmar Kühn":                            "Othmar Kühn",
    # ─ Produktionszentren ─
    "Geschichte des Akkordeonbaus in Klingenthal":
                                              "History of accordion building in Klingenthal",
    "Castelfidardo":                          "Castelfidardo",
    # ─ Akkordeon-Vorläufer ─
    "Maultrommel":                            "Jew's harp",
    "Sheng (Instrument)":                     "Sheng (instrument)",
    "Aeoline (Musikinstrument)":              "Aeoline (musical instrument)",
    "Physharmonika":                          "Physharmonika",
    "Symphonium":                             "Symphonium",
    # ─ Diatonische Akkordeons ─
    "Schrammelharmonika":                     "Schrammelharmonika",
    "Konzertina":                             "Concertina",
    "Bandoneon":                              "Bandoneon",
    "Diatonisches Akkordeon":                 "Diatonic accordion",
    "Wiener Modell":                          "Vienna model",
    "Organetto":                              "Organetto",
    "Französisches Akkordeon":                "French accordion",
    "Schottisches Akkordeon":                 "Scottish accordion",
    "Irisches Akkordeon":                     "Irish accordion",
    "Heligonka":                              "Heligonka",
    "Steirische Harmonika":                   "Styrian harmonica",
    "Trikitixa":                              "Trikitixa",
    "Schwyzerörgeli":                         "Schwyzerörgeli",
    # ─ Chromatische Akkordeons ─
    "Chromatisches Knopfakkordeon":           "Chromatic button accordion",
    "Garmon":                                 "Garmon",
    "Bajan":                                  "Bayan",
    "Pianoakkordeon":                         "Piano accordion",
    # ─ Mechanische Automaten und Harmonium ─
    "Harmonium":                              "Harmonium",
    "Orchestrion":                            "Orchestrion",
    "Panharmonikon":                          "Panharmonikon",
    "Apollonicon":                            "Apollonicon",
    "Belloneon":                              "Belloneon",
    "Mechanischer Trompeter":                 "Mechanical trumpeter",
    "Schachtürke":                            "Mechanical Turk (Schachtürke)",
    # ─ Förderer der Durchschlagzungen ─
    "Georg Joseph Vogler":                    "Georg Joseph Vogler",
    "Wolfgang von Kempelen":                  "Wolfgang von Kempelen",
    "Johann Nepomuk Mälzel":                  "Johann Nepomuk Mälzel",
    "Leonhard Mälzel":                        "Leonhard Mälzel",
    "Friedrich Kaufmann (Instrumentenbauer)": "Friedrich Kaufmann (instrument maker)",
    "Ignaz Kober":                            "Ignaz Kober",
    "Johannes Weinrich (Volkskünstler)":      "Johannes Weinrich (folk artist)",
    "Franz Leppich":                          "Franz Leppich",
    # ─ Andere Instrumente mit Durchschlagzunge ─
    "Harmonichord":                           "Harmonichord",
    "Terpodion":                              "Terpodion",
    "Aerophon":                               "Aerophone",
    "Mundharmonika":                          "Harmonica",
    "Glasharmonika":                          "Glass harmonica",
    "Aeolsharfe":                             "Aeolian harp",
    "Anemochord":                             "Anemochord",
}

# Dem verarbeite_quellen_en-Modul zur Verfügung stellen (für baue_kapitel)
vq.TITEL_EN = TITEL_EN

# ──────────────────────────────────────────────────────────
# Aufteilung exakt wie DE Band 1 / Band 2
# ──────────────────────────────────────────────────────────
BAND1 = [
    ("Bellows Instruments", [
        "Harmonikainstrument",
        "Handzuginstrument",
        "Akkordeon",
    ]),
    ("Function and History of the Free Reed", [
        "Zunge (Tonerzeuger)",
        "Durchschlagende Zunge",
    ]),
    ("Components and Mechanics", [
        "Kanzelle",
        "Cassotto",
        "Register (Akkordeon)",
        "Tremolo (Akkordeon)",
        "Stradella-Bass",
        "Konverterbass",
        "Melodiebass",
        "Helikonstimmplatten",
        "Gleichton",
        "Wechseltönig",
        "Wechselbass",
    ]),
    ("Theory and the Trade", [
        "Stimmung (Musik)",
        "Diatonik",
        "Vallotti-Stimmung",
        "Handzuginstrumentenmacher",
        "Akkordeonschule",
    ]),
    ("Inventors and Pioneers of the Accordion", [
        "Christian Gottlieb Kratzenstein",
        "Bernhard Eschenbach",
        "Johann Caspar Schlimbach",
        "Carl Friedrich Voit",
        "Friedrich Sturm (Instrumentenbauer)",
        "Anton Haeckl",
        "Anton Reinlein",
        "Christian Friedrich Ludwig Buschmann",
        "Cyrill Demian",
        "Charles Wheatstone",
        "William M. Goodrich",
        "Adolf Müller senior",
    ]),
    ("Notable Accordion Builders (Helicon Basses)", [
        "Johann Wilhelm Rudolph Glier",
        "Paolo Soprani",
        "Josef Hlaváček",
        "Lubas & Sohn",
        "Josef Fleiß",
        "Anton Mervar",
        "Peter Stachl",
        "Novak Harmonikas",
        "Otto Ludwig (Harmonikabauer)",
        "Roman Gombotz",
        "Othmar Kühn",
    ]),
    ("Centres of Production", [
        "Geschichte des Akkordeonbaus in Klingenthal",
        "Castelfidardo",
    ]),
]

BAND2 = [
    ("Precursors of the Accordion", [
        "Maultrommel",
        "Sheng (Instrument)",
        "Aeoline (Musikinstrument)",
        "Physharmonika",
        "Symphonium",
    ]),
    ("Diatonic Accordions", [
        "Schrammelharmonika",
        "Konzertina",
        "Bandoneon",
        "Diatonisches Akkordeon",
        "Wiener Modell",
        "Organetto",
        "Französisches Akkordeon",
        "Schottisches Akkordeon",
        "Irisches Akkordeon",
        "Heligonka",
        "Steirische Harmonika",
        "Trikitixa",
        "Schwyzerörgeli",
    ]),
    ("Chromatic Accordions", [
        "Chromatisches Knopfakkordeon",
        "Garmon",
        "Bajan",
        "Pianoakkordeon",
        "Bassakkordeon",
    ]),
    ("Mechanical Automata with Free Reeds", [
        "Harmonium",
        "Orchestrion",
        "Panharmonikon",
        "Apollonicon",
        "Belloneon",
        "Mechanischer Trompeter",
        "Schachtürke",
    ]),
    ("Promoters of the Free Reed", [
        "Georg Joseph Vogler",
        "Wolfgang von Kempelen",
        "Johann Nepomuk Mälzel",
        "Leonhard Mälzel",
        "Friedrich Kaufmann (Instrumentenbauer)",
        "Ignaz Kober",
        "Johannes Weinrich (Volkskünstler)",
        "Franz Leppich",
    ]),
    ("Other Free-Reed Instruments", [
        "Harmonichord",
        "Terpodion",
        "Aerophon",
        "Mundharmonika",
        "Glasharmonika",
        "Aeolsharfe",
        "Anemochord",
    ]),
]

# ──────────────────────────────────────────────────────────
# Hilfsfunktionen
# ──────────────────────────────────────────────────────────
base = '/home/claude/buch_arbeit'

def slugify(s):
    s = s.lower()
    s = re.sub(r'[äÄ]', 'ae', s); s = re.sub(r'[öÖ]', 'oe', s)
    s = re.sub(r'[üÜ]', 'ue', s); s = re.sub(r'ß', 'ss', s)
    s = re.sub(r'[^a-z0-9]+', '_', s)
    return s.strip('_')

def baue_band(band_nr, untertitel_kurz, untertitel_lang, kapitel_struktur, einleitung_pfad):
    """Baut einen englischen Band."""
    print(f"\n{'='*60}")
    print(f"Volume {band_nr}: {untertitel_lang}")
    print(f"{'='*60}")

    # vq.KAPITEL für diesen Band setzen — zur Wiederverwendung von vq.main()
    vq.KAPITEL = kapitel_struktur

    # Quellen-Ordner aufbauen
    quellen = f'{base}/quellen_en_band{band_nr}'
    ausgabe = f'{base}/buch_en_band{band_nr}'
    os.makedirs(f'{quellen}/artikel', exist_ok=True)
    os.makedirs(f'{quellen}/bilder',  exist_ok=True)

    # Übersetzte _en.wiki-Dateien als slug.wiki kopieren
    src_wiki = f'{base}/translation_test'
    for teil, artikel_liste in kapitel_struktur:
        for titel in artikel_liste:
            slug = slugify(titel)
            sp = f'{src_wiki}/{slug}_en.wiki'
            dp = f'{quellen}/artikel/{slug}.wiki'
            if os.path.exists(sp):
                shutil.copy(sp, dp)
            else:
                print(f"  WARNUNG: {sp} nicht gefunden!")

    # Bilder-Index filtern
    orig_idx = json.load(open(f'{base}/akkordeon_quellen/bilder_index.json'))
    slugs = [slugify(t) for _, al in kapitel_struktur for t in al]
    filtered = {k: orig_idx.get(k, []) for k in slugs}
    json.dump(filtered, open(f'{quellen}/bilder_index.json', 'w'))

    copied = 0
    for k, files in filtered.items():
        for f in files:
            sp = f'{base}/akkordeon_quellen/bilder/{f}'
            if os.path.exists(sp):
                shutil.copy(sp, f'{quellen}/bilder/{f}')
                copied += 1
    print(f"  Bilder bereitgestellt: {copied}")

    # LaTeX generieren
    saved_argv = sys.argv
    sys.argv = ['verarbeite_quellen_en',
                '--quellen', quellen,
                '--ausgabe', ausgabe]
    os.chdir(base)
    vq.main()
    sys.argv = saved_argv

    # Titelseite anpassen: Untertitel "Volume I/II — …" einfügen
    buch_tex = f'{ausgabe}/buch.tex'
    content = open(buch_tex, 'r', encoding='utf-8').read()

    # Untertitel zwischen "...Its History\par}" und "\vspace{2.0cm}"
    untertitel_block = (
        f"\\vspace{{1.0cm}}\n"
        f"{{\\sffamily\\large\\color{{t0blue!70!black}}\n"
        f"Volume {band_nr} --- {untertitel_lang}\\par}}\n"
    )
    content = content.replace(
        "and Its History\\par}\n\\vspace{2.0cm}",
        f"and Its History\\par}}\n{untertitel_block}\\vspace{{1.6cm}}",
        1
    )

    # Header anpassen — Bandnummer in linker geraden Kopfzeile
    content = content.replace(
        '\\fancyhead[LE]{\\small\\textcolor{t0gray}{\\thepage \\quad \\textit{The Accordion and Its History}}}',
        f'\\fancyhead[LE]{{\\small\\textcolor{{t0gray}}{{\\thepage \\quad \\textit{{The Accordion and Its History --- Vol. {band_nr}}}}}}}',
        1
    )

    # Einleitung einfügen vor \tableofcontents
    einl_tex = open(einleitung_pfad, 'r', encoding='utf-8').read()
    content = content.replace('\\tableofcontents',
                              einl_tex + '\n\n\\tableofcontents', 1)

    open(buch_tex, 'w', encoding='utf-8').write(content)
    print(f"  Untertitel + Einleitung eingefügt.")

    # Kompilieren
    for run in range(2):
        result = subprocess.run(
            ['lualatex', '-interaction=nonstopmode', 'buch.tex'],
            cwd=ausgabe, capture_output=True, text=True
        )
        m = re.search(r'Output written.*\((\d+) pages, (\d+) bytes',
                      result.stdout + result.stderr)
        if m:
            print(f"  Run {run+1}: {m.group(1)} Seiten, {int(m.group(2))/1024/1024:.1f} MB")

    pdf = f'{ausgabe}/buch.pdf'
    if os.path.exists(pdf):
        return pdf
    return None


# ──────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────
pdf1 = baue_band(
    1, "Construction",
    "Construction, Components, Builders",
    BAND1,
    f'{base}/einleitung_en_band1.tex'
)
pdf2 = baue_band(
    2, "Accordion Types",
    "Accordion Types and Related Instruments",
    BAND2,
    f'{base}/einleitung_en_band2.tex'
)

print("\n" + "="*60)
print("Final Output:")
print("="*60)
if pdf1: print(f"  Volume 1: {pdf1}")
if pdf2: print(f"  Volume 2: {pdf2}")
