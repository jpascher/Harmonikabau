#!/usr/bin/env python3
"""
Finaler englischer Bucherstellungs-Wrapper: baut das komplette EN-Buch mit
allen 91 Artikeln und der englischen Einleitung.
"""
import sys, os, shutil, subprocess
sys.path.insert(0, '/home/claude')
import verarbeite_quellen_en as vq

# ──────────────────────────────────────────────────────────
# Kapitelstruktur (91 Artikel in 8 Teilen)
# ──────────────────────────────────────────────────────────
vq.KAPITEL = [
    ("Components", [
        "Cassotto",
        "Stradella-Bass",
        "Durchschlagende Zunge",
        "Kanzelle",
        "Helikonstimmplatten",
        "Gleichton",
        "Konverterbass",
        "Melodiebass",
        "Bassakkordeon",
        "Wechselbass",
        "Wechseltönig",
        "Register (Akkordeon)",
        "Akkordeonschule",
        "Zunge (Tonerzeuger)",
        "Handzuginstrument",
        "Handzuginstrumentenmacher",
        "Aerophon",
        "Harmonikainstrument",
    ]),
    ("Pioneers", [
        "Cyrill Demian",
        "Charles Wheatstone",
        "Wolfgang von Kempelen",
        "Johann Nepomuk Mälzel",
        "Georg Joseph Vogler",
        "Christian Friedrich Ludwig Buschmann",
        "Franz Leppich",
        "Christian Gottlieb Kratzenstein",
        "Bernhard Eschenbach",
        "Johann Caspar Schlimbach",
        "Carl Friedrich Voit",
        "Anton Haeckl",
        "Ignaz Kober",
        "Friedrich Kaufmann (Instrumentenbauer)",
        "Friedrich Sturm (Instrumentenbauer)",
        "Adolf Müller senior",
        "Leonhard Mälzel",
        "William M. Goodrich",
        "Anton Reinlein",
        "Anton Mervar",
        "Johann Wilhelm Rudolph Glier",
        "Johannes Weinrich (Volkskünstler)",
        "Josef Fleiß",
        "Josef Hlaváček",
        "Othmar Kühn",
        "Otto Ludwig (Harmonikabauer)",
        "Peter Stachl",
        "Roman Gombotz",
        "Lubas & Sohn",
        "Paolo Soprani",
    ]),
    ("Mechanical Music Machines", [
        "Panharmonikon",
        "Orchestrion",
        "Mechanischer Trompeter",
        "Harmonichord",
        "Apollonicon",
        "Belloneon",
        "Symphonium",
    ]),
    ("Accordion Family", [
        "Akkordeon",
        "Steirische Harmonika",
        "Schwyzerörgeli",
        "Konzertina",
        "Bandoneon",
        "Schrammelharmonika",
        "Diatonisches Akkordeon",
        "Wiener Modell",
        "Chromatisches Knopfakkordeon",
        "Pianoakkordeon",
        "Bajan",
        "Garmon",
        "Heligonka",
        "Trikitixa",
        "Französisches Akkordeon",
        "Irisches Akkordeon",
        "Schottisches Akkordeon",
        "Tremolo (Akkordeon)",
        "Organetto",
    ]),
    ("Related Instruments", [
        "Physharmonika",
        "Harmonium",
        "Mundharmonika",
        "Maultrommel",
        "Glasharmonika",
        "Aeolsharfe",
        "Terpodion",
        "Aeoline (Musikinstrument)",
        "Anemochord",
        "Sheng (Instrument)",
    ]),
    ("Music Theory", [
        "Stimmung (Musik)",
        "Diatonik",
        "Vallotti-Stimmung",
    ]),
    ("Manufacturers", [
        "Novak Harmonikas",
        "Castelfidardo",
        "Geschichte des Akkordeonbaus in Klingenthal",
    ]),
    ("Curiosities", [
        "Schachtürke",
    ]),
]

# ──────────────────────────────────────────────────────────
# Quellen-Ordner aufbauen
# ──────────────────────────────────────────────────────────
base      = '/home/claude/buch_arbeit'
src_wiki  = f'{base}/translation_test'
quellen   = f'{base}/quellen_en_komplett'
ausgabe   = f'{base}/buch_en_komplett'

os.makedirs(f'{quellen}/artikel', exist_ok=True)
os.makedirs(f'{quellen}/bilder',  exist_ok=True)

# Alle 91 _en.wiki-Dateien kopieren (slug-Name = Dateiname)
import json, re

def slugify(s):
    s = s.lower()
    s = re.sub(r'[äÄ]', 'ae', s); s = re.sub(r'[öÖ]', 'oe', s)
    s = re.sub(r'[üÜ]', 'ue', s); s = re.sub(r'ß',    'ss', s)
    s = re.sub(r'[^a-z0-9]+', '_', s)
    return s.strip('_')

for teil, artikel_liste in vq.KAPITEL:
    for titel in artikel_liste:
        slug = slugify(titel)
        src  = f'{src_wiki}/{slug}_en.wiki'
        dst  = f'{quellen}/artikel/{slug}.wiki'
        if os.path.exists(src):
            shutil.copy(src, dst)
        else:
            print(f"WARNUNG: {src} nicht gefunden!")

# Bilder-Index aus Original kopieren und filtern
orig_idx = json.load(open(f'{base}/akkordeon_quellen/bilder_index.json'))
slugs    = [slugify(t) for _, al in vq.KAPITEL for t in al]
filtered = {k: orig_idx.get(k, []) for k in slugs}
json.dump(filtered, open(f'{quellen}/bilder_index.json', 'w'))

# Bilder kopieren
copied = 0
for k, files in filtered.items():
    for f in files:
        sp = f'{base}/akkordeon_quellen/bilder/{f}'
        if os.path.exists(sp):
            shutil.copy(sp, f'{quellen}/bilder/{f}')
            copied += 1

print(f"Artikel: {len(os.listdir(quellen+'/artikel'))}, Bilder: {copied}")

# ──────────────────────────────────────────────────────────
# LaTeX generieren
# ──────────────────────────────────────────────────────────
sys.argv = ['verarbeite_quellen_en',
            '--quellen', quellen,
            '--ausgabe', ausgabe]
os.chdir(base)
vq.main()

# ──────────────────────────────────────────────────────────
# Einleitung einfügen
# ──────────────────────────────────────────────────────────
buch_tex = f'{ausgabe}/buch.tex'
with open(buch_tex, 'r', encoding='utf-8') as fh:
    content = fh.read()

einl_tex = open(f'{base}/einleitung_en.tex', 'r', encoding='utf-8').read()

# Nach LIZENZSEITE und \clearpage einfügen (vor \tableofcontents)
marker = r'\tableofcontents'
content = content.replace(marker, einl_tex + '\n\n' + marker, 1)

with open(buch_tex, 'w', encoding='utf-8') as fh:
    fh.write(content)

print("Einleitung eingefügt.")

# ──────────────────────────────────────────────────────────
# Kompilieren
# ──────────────────────────────────────────────────────────
for run in range(2):
    result = subprocess.run(
        ['lualatex', '-interaction=nonstopmode', 'buch.tex'],
        cwd=ausgabe, capture_output=True, text=True
    )
    if 'Output written' in result.stdout or 'Output written' in result.stderr:
        m = __import__('re').search(r'Output written.*\((\d+) pages', result.stdout+result.stderr)
        if m: print(f"Run {run+1}: {m.group(1)} Seiten")
    else:
        # Zeige letzte Fehler
        for line in (result.stdout+result.stderr).split('\n')[-20:]:
            if line.strip(): print(line)

pdf = f'{ausgabe}/buch.pdf'
if os.path.exists(pdf):
    size_mb = os.path.getsize(pdf) / 1024 / 1024
    print(f"\n✓ PDF fertig: {pdf}  ({size_mb:.1f} MB)")
else:
    print("✗ PDF nicht erzeugt!")
